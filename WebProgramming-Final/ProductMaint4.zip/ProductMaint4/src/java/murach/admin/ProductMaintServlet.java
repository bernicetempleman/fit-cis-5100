/*
Bernice Templeman
CIS 5740/ Spring 2016
Product Maintenance 4 (Program 5 part 1)
*/

package murach.admin;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.List;
import java.util.regex.Pattern;
import murach.business.Product;
import murach.data.ProductDB;

public class ProductMaintServlet extends HttpServlet 
{
 @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
        // get the products and place into session var
        ServletContext sc = getServletContext();
    
        HttpSession session = request.getSession();
        session.setAttribute("products", ProductDB.selectAll());
        session.setAttribute("error", null);
    
        String action = request.getParameter("action");
        
        if (action == null)
            action = "displayProducts";
       
        String url = "/products.jsp";

        if (action.equals("displayProducts"))
        { 
            session.setAttribute("products", ProductDB.selectAll());
            url = "/products.jsp";
        }
        
    else if  (action.equals("addProduct"))
    {
        // set a product into the session if indicated, otherwise clear it
        if (request.getParameter("productCode") != null) 
        {
            session.setAttribute("product", ProductDB.selectByCode(request.getParameter("productCode")));
        } 
        else 
        {
            session.setAttribute("product", null);
        }
        
        url = "/addProduct.jsp";
    }
       
    else if (action.equals( "addConfirmed"))
    {
        // create temp product
        Product product = ProductDB.selectByCode(request.getParameter("prodCode"));
        Boolean isInsert = false;
        if (product == null) 
        {
            isInsert = !isInsert;
            product = new Product();
        }
        
        // get parameters from the request
        String prodCode = request.getParameter("prodCode");
        String prodDescription = request.getParameter("prodDescription");
        String prodPrice = request.getParameter("prodPrice");
           
        product.setCode(prodCode);
        product.setDescription(prodDescription);  
        
        double prodPriceD = 0.0;
        String message = "";
        boolean match = false;
        
        if(!prodPrice.isEmpty())
        {
            //check if price is valid double value          
            String doublePattern = "([0-9].*)\\.([0-9].*)";
            match = Pattern.matches(doublePattern, (request.getParameter("prodPrice")));
            if (match)
            {
                try
                {
                    prodPriceD = Double.valueOf(request.getParameter("prodPrice"));

                }
                catch(Exception e)
                {
                    product.setPrice(prodPriceD);
                    session.setAttribute("product", product);
                    match = false;
                    message = "You must enter a valid price for the product. Example: 1.00";
                    request.setAttribute("message", message);
                    url = "/addProduct.jsp";
  
                }
            }
        }// prod price is not empty
        else //prod price is empty
        {
                // store the Product object in the session
                match = false;
                message = "You must enter a valid price for the product. Example: 1.00";
                request.setAttribute("message", message);
                url = "/addProduct.jsp";             
        }
          
        product.setPrice(prodPriceD);
        session.setAttribute("product", product);
        
        if (match)
        {      
        //check if all values complete
        if ((prodCode.isEmpty() || prodDescription.isEmpty()) || prodPrice.isEmpty())
        {
            // forward to the view to get missing parameters
            url = "/addProduct.jsp";
                                
            if (prodCode.isEmpty())
                message = "You must enter a code for the product.";
            else if (prodDescription.isEmpty())
                message = "You must enter a description for the product.";
            else if (prodPrice.isEmpty())
            
                message = "You must enter a price for the product.";
            request.setAttribute("message", message);
            
        }
        else //all complete
        {
            //check if price is valid double value          
            String doublePattern = "([0-9].*)\\.([0-9].*)";
            match = Pattern.matches(doublePattern, (request.getParameter("prodPrice")));
           
            if(match) //check if 2 decimal places
            {
                String[] splitter = (request.getParameter("prodPrice")).split("\\.");
                splitter[0].length();   // Before Decimal Count
                int decimalLength = splitter[1].length();  // After Decimal Count

                if (decimalLength == 2)
                {     
                    // decide between update and insert
                    if (!isInsert) 
                    {
                        ProductDB.update(product);
                    } 
                    else
                    {
                        ProductDB.insert(product);
                    }          
                    session.setAttribute("products", ProductDB.selectAll());
                    url = "/products.jsp";
                }
                else  
                {
                    message = "You must enter a valid price for the product. Example: 1.00";
                    request.setAttribute("message", message);
                    url = "/addProduct.jsp"; 
                }
                
            }//if match
            else
            {
                message = "You must enter a valid price for the product. Example: 1.00";
                request.setAttribute("message", message);
                url = "/addProduct.jsp"; 
            }
        }//end if all complete
        
        }//end if match
        else
        {
                message = "You must enter a valid price for the product. Example: 1.00";
                request.setAttribute("message", message);
                url = "/addProduct.jsp"; 
         }
        
        sc.getRequestDispatcher(url).forward(request, response);  
    }//end add confirmed
                
    else if (action.equals( "deleteProduct"))
    {
        // set a product into the session if indicated, otherwise clear it
        if (request.getParameter("productCode") != null) 
        {
            session.setAttribute("product", ProductDB.selectByCode(request.getParameter("productCode")));
        } else 
        {
            session.setAttribute("product", null);
        }
        
        url = "/deleteProduct.jsp";
    }
        
    else if (action.equals( "deleteConfirmed"))
    {
        Product delProduct = (Product) session.getAttribute("product");
        if (delProduct != null) 
        {
            ProductDB.delete(delProduct);
        }
        
        session.setAttribute("products", ProductDB.selectAll());
        url = "/products.jsp";
        
    }

    sc.getRequestDispatcher(url).forward(request, response);
  }
  
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    doPost(request, response);
  }  
}
