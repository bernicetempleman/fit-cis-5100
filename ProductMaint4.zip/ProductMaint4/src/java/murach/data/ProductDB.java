/*
Bernice Templeman
CIS 5740/ Spring 2016
Product Maintenance 4
*/
package murach.data;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import murach.business.Product;

public class ProductDB 
{
     public static List<Product> selectAll() {
    EntityManager em = DBUtil.getEmFactory().createEntityManager();
    String qString = "SELECT u FROM Product u";
    TypedQuery<Product> q = em.createQuery(qString, Product.class);

    List<Product> products;
    try {
      products = q.getResultList();
    } catch (NoResultException e) {
      System.out.println(e);
      products = null;
    } finally {
      em.close();
    }
    return products;
  }
       
  public static Product selectByCode(String code) {
    EntityManager em = DBUtil.getEmFactory().createEntityManager();
    String qString = "SELECT u FROM Product u WHERE u.code = :code";
    TypedQuery<Product> q = em.createQuery(qString, Product.class);
    q.setParameter("code", code);
    
    Product product = null;
    try {
      product = q.getSingleResult();
    } catch (NoResultException e) {
      System.out.println(e);
      product = null;
    } finally {
      em.close();
    }
    return product;
  }
      
  public static void update(Product product) {
    EntityManager em = DBUtil.getEmFactory().createEntityManager();
    EntityTransaction trans = em.getTransaction();
    try {
      trans.begin();
      em.merge(product);
      trans.commit();
    } catch (Exception e) {
      System.out.println(e);
      trans.rollback();
    } finally {
      em.close();
    }
  }
    
  public static void insert(Product product) {
    EntityManager em = DBUtil.getEmFactory().createEntityManager();
    EntityTransaction trans = em.getTransaction();
    try {
      trans.begin();
      em.persist(product);
      trans.commit();
    } catch (Exception e) {
      System.out.println(e);
      trans.rollback();
    } finally {
      em.close();
    }
  }
   
  public static void delete(Product product) {
    EntityManager em = DBUtil.getEmFactory().createEntityManager();
    EntityTransaction trans = em.getTransaction();      
    try {
      trans.begin();
      em.remove(em.merge(product));
      trans.commit();
    } catch (Exception e) {
      System.out.println(e);
      trans.rollback();
    } finally {
      em.close();
    }       
  }
}
