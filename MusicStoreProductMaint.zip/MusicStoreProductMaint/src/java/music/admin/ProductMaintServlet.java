/*
Bernice Templeman
CIS 5740/ Spring 2016
Music Store Product Maintenance 
*/

package music.admin;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.regex.Pattern;
import music.business.Product;
import music.data.ProductDB;

public class ProductMaintServlet extends HttpServlet 
{
 @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
        // get the products and place into session var
        ServletContext sc = getServletContext();
    
        HttpSession session = request.getSession();
        session.setAttribute("products", ProductDB.selectAll());
        session.setAttribute("error", null);
    
        String action = request.getParameter("action");
        
        if (action == null)
            action = "displayProducts";
       
        String url = "/admin/products.jsp";

        if (action.equals("displayProducts"))
        { 
            session.setAttribute("products", ProductDB.selectAll());
            url = "/admin/products.jsp";
        }
        
    else if  (action.equals("addProduct"))
    {
        // set a product into the session if indicated, otherwise clear it
        if (request.getParameter("productCode") != null) 
        {
            session.setAttribute("product", ProductDB.selectByCode(request.getParameter("productCode")));
        } 
        else 
        {
            session.setAttribute("product", null);
        }
        
        url = "/admin/addProduct.jsp";
    }
        
    else if (action.equals( "addConfirmed"))
    {
        // create temp product
        Product product = ProductDB.selectByCode(request.getParameter("prodCode"));
        Boolean isInsert = false;
        if (product == null) 
        {
            isInsert = !isInsert;
            product = new Product();
        }
        
        // populate these first, in case of Double error
        String prodCode = request.getParameter("prodCode");
        String prodDesc = request.getParameter("prodDescription");
        product.setCode(prodCode);
        product.setDescription(prodDesc);
        
        
        String prodPrice = request.getParameter("prodPrice");
        double prodPriceD = 0;
        
        if(!prodPrice.isEmpty())
        {
                prodPriceD = Double.valueOf(request.getParameter("prodPrice"));
        }
        product.setPrice(prodPriceD);
        
        // store the Product object in the session
        session.setAttribute("product", product);
        
        String message = "";
        
        //check if all values complete
        if ((prodCode.isEmpty() || prodDesc.isEmpty()) || prodPrice.isEmpty())
        {
            // forward to the view to get missing parameters
            url = "/admin/addProduct.jsp";
                                
            if (prodCode.isEmpty())
                    message = "You must enter a code for the product.";
            if (prodDesc.isEmpty())
                    message = "You must enter a description for the product.";
            if (prodPrice.isEmpty())
                    message = "You must enter a price for the product.";
            request.setAttribute("message", message);
        }
        else //all complete
        {
            //check if price is valid double value          
            String doublePattern = "([0-9].*)\\.([0-9].*)";
            boolean match = Pattern.matches(doublePattern, (request.getParameter("prodPrice")));
           
            if(match) //check if 2 decimal places
            {
                String[] splitter = (request.getParameter("prodPrice")).split("\\.");
                splitter[0].length();   // Before Decimal Count
                int decimalLength = splitter[1].length();  // After Decimal Count

                if (decimalLength == 2)
                {
                    if (isInsert) 
                    {
                        ProductDB.insert(product);
                    } 
                    else 
                    {
                        ProductDB.update(product);
                    }
                    // store the Products in the session
                    session.setAttribute("products", ProductDB.selectAll());
                    url = "/admin/products.jsp";
                }
                else //not valid price
                {
                    message = "You must enter a valid price for the product.";
                    request.setAttribute("message", message);
                    url = "/admin/addProduct.jsp";
                }
            }//price was a valid number
            else //not valid price
            {
                 message = "You must enter a valid price for the product.";
                 request.setAttribute("message", message);
                 url = "/admin/addProduct.jsp";
            }
        }// if all complete
    
    }//end if add confirmed
                
    else if (action.equals( "deleteProduct"))
    {
        // set a product into the session if indicated, otherwise clear it
        if (request.getParameter("productCode") != null) 
        {
            session.setAttribute("product", ProductDB.selectByCode(request.getParameter("productCode")));
        } else 
        {
            session.setAttribute("product", null);
        }
        
        url = "/admin/deleteProduct.jsp";
    }
        
    else if (action.equals( "deleteConfirmed"))
    {
        Product delProduct = (Product) session.getAttribute("product");
        if (delProduct != null) 
        {
            ProductDB.delete(delProduct);
        }
        
        session.setAttribute("products", ProductDB.selectAll());
        url = "/admin/products.jsp";
        
    }

    sc.getRequestDispatcher(url).forward(request, response);
  }
  
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    doPost(request, response);
  }  
}
/*
package music.admin;


import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.List;
import java.util.regex.Pattern;
import music.business.Product;
import music.data.ProductDB;



public class ProductMaintServlet extends HttpServlet 
{
 @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    // get the products and place into session var
    ServletContext sc = getServletContext();
    // String path = sc.getRealPath("/WEB-INF/products.txt");
    // ProductIO.init(path);
    
    HttpSession session = request.getSession();
    session.setAttribute("products", ProductDB.selectAll());
    session.setAttribute("error", null);
    
    // decide what to do based on action param
    String action = request.getParameter("action");
    if (action == null)
    {
      session.setAttribute("products", ProductDB.selectAll());
      action = "displayProducts";
    }
       
    String url = "/admin/products.jsp";
    

    if (action.equals("displayProducts"))
    { 
        session.setAttribute("products", ProductDB.selectAll());
        url = "/admin/products.jsp";
    }
        
    else if  (action.equals("addProduct"))
    {
        // set a product into the session if indicated, otherwise clear it
        if (request.getParameter("productCode") != null) {
          session.setAttribute("product", ProductDB.selectByCode(request.getParameter("productCode")));
        } else {
          session.setAttribute("product", null);
        }
        
        url = "/admin/addProduct.jsp";
    }
        
    else if (action.equals( "addConfirmed"))
    {
        // create temp product
        Product newProduct = ProductDB.selectByCode(request.getParameter("prodCode"));
        Boolean isInsert = false;
        if (newProduct == null) {
          isInsert = !isInsert;
          newProduct = new Product();
        }
        
        // populate these first, in case of Double error
        String prodCode = request.getParameter("prodCode");
        String prodDesc = request.getParameter("prodDescription");
        newProduct.setCode(prodCode);
        newProduct.setDescription(prodDesc);
        session.setAttribute("product", newProduct);
        
        try {
          // validate server side
          if (prodCode.isEmpty() || prodDesc.isEmpty()) {
            throw new Exception("Either product code or description is empty.");
          }
          
          // possible number error exception
          Double prodPrice = Double.parseDouble(request.getParameter("prodPrice"));
          newProduct.setPrice(prodPrice);
          session.setAttribute("product", newProduct);
          
          // decide between update and insert
          if (isInsert) {
            ProductDB.insert(newProduct);
          } else {
            ProductDB.update(newProduct);
          }

          session.setAttribute("products", ProductDB.selectAll());
          url = "/admin/products.jsp";
        }
        catch (Exception e)
        {
          // user input is improper
          System.out.println(e);
          session.setAttribute("error", true);
          url = "/admin/addProduct.jsp";
        }
    }
                
    else if (action.equals( "deleteProduct"))
    {
        // set a product into the session if indicated, otherwise clear it
        if (request.getParameter("productCode") != null) {
          session.setAttribute("product", ProductDB.selectByCode(request.getParameter("productCode")));
        } else {
          session.setAttribute("product", null);
        }
        
        url = "/admin/deleteProduct.jsp";
    }
        
    else if (action.equals( "deleteConfirmed"))
    {
        Product delProduct = (Product) session.getAttribute("product");
        if (delProduct != null) {
          ProductDB.delete(delProduct);
        }
        
        session.setAttribute("products", ProductDB.selectAll());
        url = "/admin/products.jsp";
        
    }
    else
    {
        session.setAttribute("products", ProductDB.selectAll());
        url = "/admin/products.jsp";
    }
    

    sc.getRequestDispatcher(url).forward(request, response);
  }
  
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    doPost(request, response);
  }  
}
    
    /*
  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    // get the products and place into session var
    ServletContext sc = getServletContext();
    String path = sc.getRealPath("/WEB-INF/products.txt");
    //ProductIO.init(path);
    List<Product> products = ProductDB.selectProducts();
    HttpSession session = request.getSession();
    session.setAttribute("products", products);
    
    // decide what to do based on action param
    String action = request.getParameter("action");
    if (action == null)
      action = "displayProducts";
    
    String url = "/products.jsp";

    if (action.equals("displayProducts"))
    { 
        url = "/products.jsp";
           
            // get list of users
            List<Product> users = ProductDB.selectProducts();            
            request.setAttribute("products", products);
    }
    
        
    else if (action.equals("addProduct"))
    {
        // set a product into the session if indicated, otherwise clear it
        if (request.getParameter("productCode") != null) {
          session.setAttribute("product", ProductDB.selectProduct(request.getParameter("productCode")));
        } else {
          session.setAttribute("product", null);
        }
        
        url = "/addProduct.jsp";
    }
        
    else if (action.equals( "addConfirmed"))
    {
       Product newProduct = ProductDB.selectProduct(request.getParameter("prodCode"));
            
        // get parameters from the request
            String prodCode = request.getParameter("prodCode");
            String prodDescription = request.getParameter("prodDescription");
            String prodPrice = request.getParameter("prodPrice");
            double prodPriceD = 0;
            
  //**** add updates
            if(!prodPrice.isEmpty())
            {
                prodPriceD = Double.valueOf(request.getParameter("prodPrice"));
            }
            
            // create the User object
            Product product = new Product();
            product.setCode(prodCode);
            product.setDescription(prodDescription);
            product.setPrice(prodPriceD);
            
            // store the Product object in the session
            session.setAttribute("product", product);
           
            //check if all values complete
            if ((action.equals("addConfirmed")) &&(prodCode.isEmpty() || prodDescription.isEmpty() || prodPrice.isEmpty()))
            {
                // forward to the view to get missing parameters
                url = "/addProduct.jsp";
                                String message = "";
                if (prodCode.isEmpty())
                    message = "You must enter a code for the product.";
                if (prodDescription.isEmpty())
                    message = "You must enter a description for the product.";
                if (prodPrice.isEmpty())
                    message = "You must enter a price for the product.";
                request.setAttribute("message", message);
            }
            else //all complete
            {
                //check if price is valid double value          
                String doublePattern = "([0-9].*)\\.([0-9].*)";
                boolean match = Pattern.matches(doublePattern, (request.getParameter("prodPrice")));
           
                if(match) //check if 2 decimal places
                {
                String[] splitter = (request.getParameter("prodPrice")).split("\\.");
                splitter[0].length();   // Before Decimal Count
                int decimalLength = splitter[1].length();  // After Decimal Count

                if (decimalLength == 2)
                {     
                    // decide between update and insert
                    if (ProductDB.exists(product.getCode())) 
                    {
                        ProductDB.update(product);
                    } 
                    else
                    {
                        ProductDB.insert(product);
                    }
                    
                // forward to the view
                url = "/products.jsp";
                }
                else                        
                    url = "/addProduct.jsp"; 
                
                }
            else                        
                url = "/addProduct.jsp"; 
        }
       
    }
                
    else if(action.equals("deleteProduct"))
    {
        // set a product into the session if indicated, otherwise clear it
        if (request.getParameter("productCode") != null) {
          session.setAttribute("product", ProductDB.selectProduct(request.getParameter("productCode")));
        } else {
          session.setAttribute("product", null);
        }
        
        url = "/deleteProduct.jsp";
    }
        
    else if(action.equals( "deleteConfirmed"))
    {
        Product delProduct = (Product) session.getAttribute("product");
        if (delProduct != null)
        {
          ProductDB.delete(delProduct);
        }
        
        url = "/products.jsp";
        
    }
    else if (action.equals("displayProducts"))
    { 
        url = "/products.jsp";
    }
    
    sc.getRequestDispatcher(url).forward(request, response);
    
    //getServletContext().getRequestDispatcher(url)
    //           .forward(request, response);
  }
  
  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    doPost(request, response);
  }   
}
*/