/*
29.4 Shopping Cart Application
Using the techniques you learned
in Section 29.8.2, create a simple shopping cart application.

1. Display a list of books as an h:selectOneRadio element.
2. When the user submits the form, 
store the user's selection in a @SessionScoped managed bean.
3. Allow the user to return to the list of books and make additional selections
4. Provide a link to view the shopping cart.

On the shopping cart page, display 
the list of selections the user made
the price of each book and
the total of all books in the cart.
*/
package shoppingcart;

import java.io.Serializable;
import static java.lang.reflect.Array.set;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import static java.util.Spliterators.iterator;
import static java.util.Spliterators.iterator;
import java.util.TreeSet;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import static org.apache.xml.security.keys.keyresolver.KeyResolver.iterator;

@ManagedBean( name="shoppingCartBean" )
@SessionScoped
public class ShoppingCartBean implements Serializable
{
   // map of topics to book titles
   private static final Map< String, String > booksMap =
      new HashMap< String, String >();
   

   // initialize booksMap
   static 
   {
      booksMap.put( "Java How to Program","12.99" );
      booksMap.put( "C++ How to Program","13.99" );
      booksMap.put( 
         "iPhone for Programmers: An App-Driven Approach", "14.99" );
      booksMap.put( 
         "Android for Programmers: An App-Driven Approach", "15.99" );
   } // end static initializer block

   // stores individual user's selections
   private Set< String > selections = new TreeSet< String >();
   private String selection; // stores the current selection
   
   // return number of selections
   public int getNumberOfSelections()
   {
      return selections.size();
   } // end method getNumberOfSelections
   
   // returns the current selection
   public String getSelection()
   {
      return selection;
   } // end method getSelection

   // store user's selection
   public void setSelection( String topic )
   {
      selection = booksMap.get( topic );
      selections.add( selection );
   } // end method setSelection

   // return the Set of selections
   public String[] getSelections()
   {
      return selections.toArray( new String[ selections.size() ] );
   } // end method getSelections
   
   public String getTime()
   {
   
       return DateFormat.getTimeInstance( DateFormat.LONG ).format(
         new Date() );
   } // end method getTime
   
public String getKey1(String book)
{
   for ( String key : booksMap.keySet() ) 
{
    System.out.println( key );

        return key;
    }
    return null;
}
/* Display content using Iterator*/
public String getKey(String book)
{
    System.out.println("book: " + book);
      Set set = booksMap.entrySet();
      Iterator iterator = set.iterator();
      String key = "";
      boolean done = false;
      while(!done && iterator.hasNext()) 
      {
         
         Map.Entry mentry = (Map.Entry)iterator.next();
         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
         System.out.println(mentry.getValue());
         if (book.equals(mentry.getValue().toString()))
             
         {
             done = true;
             key = mentry.getKey().toString() ;
             
         }

         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
         System.out.println(mentry.getValue());
         key = mentry.getKey().toString() ;
      }
      return key;
}

public String getValue(String book)
{
      Set set = booksMap.entrySet();
      Iterator iterator = set.iterator();
      String value = "";
      boolean done = false;
      while(!done && iterator.hasNext()) 
      {
         
         Map.Entry mentry = (Map.Entry)iterator.next();
         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
         System.out.println(mentry.getValue());
         if (book.equals(mentry.getValue().toString()))
             
         {
             done = true;
             value = mentry.getValue().toString() ;
             
         }

         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
         System.out.println(mentry.getValue());
         //key = mentry.getKey().toString() ;
         value = mentry.getValue().toString() ;
      }
      return value;
}

public String getTotal()
{
    double total = 0;
    String value = "";
    
    Iterator itr = selections.iterator();
        while(itr.hasNext())
        {
           
            value = itr.next().toString();
            System.out.println( value);
            
            total += Double.valueOf(value);
            
        }

      return Double.toString(total);
    
}

} // end class ShoppingCartBean


