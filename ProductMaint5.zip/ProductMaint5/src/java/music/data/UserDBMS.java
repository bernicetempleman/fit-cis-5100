package music.data;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import music.business.UserMS;

public class UserDBMS {
    
    public static void insert(UserMS user) {
        EntityManager em = DBUtilMS.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.persist(user);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            em.close();
        }
    }
    
    public static void update(UserMS user) {
        EntityManager em = DBUtilMS.getEmFactory().createEntityManager();
        EntityTransaction trans = em.getTransaction();
        trans.begin();
        try {
            em.merge(user);
            trans.commit();
        } catch (Exception e) {
            System.out.println(e);
            trans.rollback();
        } finally {
            em.close();
        }
    }
    
    public static UserMS selectUser(String email) {
        EntityManager em = DBUtilMS.getEmFactory().createEntityManager();
        String qString = "SELECT u FROM User u " +
                "WHERE u.email = :email";
        TypedQuery<UserMS> q = em.createQuery(qString, UserMS.class);
        q.setParameter("email", email);
        UserMS result = null;
        try {
            result = q.getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
        
        return result;
    }
    
    public static boolean emailExists(String email) {
        UserMS u = selectUser(email);   
        return u != null;
    }    
}