package music.data;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import music.business.ProductMS;

public class ProductDBMS {

    public static ProductMS selectProduct(String code) {
        EntityManager em = DBUtilMS.getEmFactory().createEntityManager();
        String qString = "SELECT p FROM Product p " +
                "WHERE p.code = :code";
        TypedQuery<ProductMS> q = em.createQuery(qString, ProductMS.class);
        q.setParameter("code", code);
        ProductMS result = null;
        try {
            result = q.getSingleResult();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
        
        return (ProductMS)result;
    }
    
    public static ProductMS selectProduct(long productId) {
        EntityManager em = DBUtilMS.getEmFactory().createEntityManager();
        
        return em.find(ProductMS.class, productId);
    }
    
    public List<ProductMS> selectProducts() {
        EntityManager em = DBUtilMS.getEmFactory().createEntityManager();
        String qString = "SELECT p from Product p";
        TypedQuery<ProductMS> q = em.createQuery(qString, ProductMS.class);
        List<ProductMS> results = null;
        try {
            results = q.getResultList();
        } catch (NoResultException ex) {
            return null;
        } finally {
            em.close();
        }
        
        return results;
    }
}